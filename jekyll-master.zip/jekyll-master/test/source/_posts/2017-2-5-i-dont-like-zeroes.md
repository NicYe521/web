---
foo: bar
---
I have an abbreviated date. Instead of "2017-02-05", I am instead "2017-2-5".
Zeros have always seemed superfluous.
